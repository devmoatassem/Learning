import './assets/App.css';
import CalcBody from './components/CalcBody';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <CalcBody/>
      </header>
    </div>
  );
}

export default App;
